import java.util.*;

public class caesercipher{
	public static final String alpha= "abcdefghijklmnopqrstuvwxyz";
	
	public static String encrypt(String message,int shiftkey){
		message=message.toLowerCase();
		String ciphertext="";
		
		for(int i=0;i<message.length();i++){
			char ch=message.charAt(i);
			int charposition=alpha.indexOf(ch);
			
			int keyvalue=(charposition+shiftkey)%26;
			char replacevalue=alpha.charAt(keyvalue);
			
			ciphertext+=replacevalue;
		}
		return ciphertext;
	}
		public static String decrypt(String message,int shiftkey){
		message=message.toLowerCase();
		String plaintext="";
		
		for(int i=0;i<message.length();i++){
			char ch=message.charAt(i);
			int charposition=alpha.indexOf(ch);
			
			int keyvalue=(charposition-shiftkey)%26;
			//char replacevalue = alpha.charAt(keyvalue);
			
			if(keyvalue<0){
				keyvalue=alpha.length()+keyvalue;
			}
		
			char replacevalue = alpha.charAt(keyvalue);
			plaintext+=replacevalue;
		}
		return plaintext;
	}
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		String originalmessage=new String();
		//String ciphertext=new String();
		int key=0;
		
		System.out.println("enter string : ");
		originalmessage=scan.nextLine();
		
		System.out.println("enter key : ");
		key=scan.nextInt();
		
		
		System.out.println("encrypt : "+ encrypt(originalmessage,key));
		System.out.println("decrypt : " + decrypt(encrypt(originalmessage,key),key));
	}
}