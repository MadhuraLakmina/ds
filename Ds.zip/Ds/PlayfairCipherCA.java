import java.util.*;

public class PlayfairCipherCA {

    private char[][] keyTable = new char[5][5];

    // ---------------- KEY TABLE ----------------
    private void generateKeyTable(String keyword) {
        boolean[] used = new boolean[26];
        keyword = keyword.toUpperCase().replaceAll("[^A-Z]", "");
        keyword = keyword.replace('J', 'I');

        StringBuilder keyString = new StringBuilder();

        // Add keyword letters
        for (char ch : keyword.toCharArray()) {
            if (!used[ch - 'A']) {
                used[ch - 'A'] = true;
                keyString.append(ch);
            }
        }

        // Add remaining alphabet letters
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            if (ch == 'J') continue;
            if (!used[ch - 'A']) {
                keyString.append(ch);
            }
        }

        // Fill table
        int index = 0;
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                keyTable[i][j] = keyString.charAt(index++);
    }

    private void displayKeyTable() {
        System.out.println("\nKey Table:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++)
                System.out.print(keyTable[i][j] + " ");
            System.out.println();
        }
    }

    // ---------------- FORMAT PLAINTEXT ----------------
    private String formatPlaintext(String text) {
        text = text.toUpperCase().replaceAll("[^A-Z]", "");
        text = text.replace('J', 'I');

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            result.append(text.charAt(i));

            if (i + 1 < text.length()) {
                if (text.charAt(i) == text.charAt(i + 1)) {
                    result.append('X');
                }
            }
        }

        if (result.length() % 2 != 0)
            result.append('Z');

        return result.toString();
    }

    // ---------------- FIND POSITION ----------------
    private int[] findPosition(char ch) {
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                if (keyTable[i][j] == ch)
                    return new int[]{i, j};
        return null;
    }

    // ---------------- ENCRYPT ----------------
    private String encryptText(String text) {
        StringBuilder cipher = new StringBuilder();

        for (int i = 0; i < text.length(); i += 2) {
            char a = text.charAt(i);
            char b = text.charAt(i + 1);

            int[] p1 = findPosition(a);
            int[] p2 = findPosition(b);

            // Same row
            if (p1[0] == p2[0]) {
                cipher.append(keyTable[p1[0]][(p1[1] + 1) % 5]);
                cipher.append(keyTable[p2[0]][(p2[1] + 1) % 5]);
            }
            // Same column
            else if (p1[1] == p2[1]) {
                cipher.append(keyTable[(p1[0] + 1) % 5][p1[1]]);
                cipher.append(keyTable[(p2[0] + 1) % 5][p2[1]]);
            }
            // Rectangle rule
            else {
                cipher.append(keyTable[p1[0]][p2[1]]);
                cipher.append(keyTable[p2[0]][p1[1]]);
            }
        }
        return cipher.toString();
    }

    // ---------------- DECRYPT ----------------
    public String decryptText(String ciphertext) {
        StringBuilder plain = new StringBuilder();

        for (int i = 0; i < ciphertext.length(); i += 2) {
            char a = ciphertext.charAt(i);
            char b = ciphertext.charAt(i + 1);

            int[] p1 = findPosition(a);
            int[] p2 = findPosition(b);

            // Same row (shift left)
            if (p1[0] == p2[0]) {
                plain.append(keyTable[p1[0]][(p1[1] + 4) % 5]);
                plain.append(keyTable[p2[0]][(p2[1] + 4) % 5]);
            }
            // Same column (shift up)
            else if (p1[1] == p2[1]) {
                plain.append(keyTable[(p1[0] + 4) % 5][p1[1]]);
                plain.append(keyTable[(p2[0] + 4) % 5][p2[1]]);
            }
            // Rectangle rule
            else {
                plain.append(keyTable[p1[0]][p2[1]]);
                plain.append(keyTable[p2[0]][p1[1]]);
            }
        }

        // Remove unnecessary X between duplicate letters
        String result = plain.toString()
                .replaceAll("X(?=[A-Z])", "");

        // Remove trailing Z
        if (result.endsWith("Z"))
            result = result.substring(0, result.length() - 1);

        return result;
    }

    // ---------------- MAIN ----------------
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PlayfairCipherCA pf = new PlayfairCipherCA();

        System.out.print("Enter Keyword: ");
        String keyword = sc.nextLine();

        System.out.print("Enter Plaintext: ");
        String plaintext = sc.nextLine();

        pf.generateKeyTable(keyword);
        pf.displayKeyTable();

        String formatted = pf.formatPlaintext(plaintext);
        System.out.println("\nFormatted Plaintext: " + formatted);

        String cipher = pf.encryptText(formatted);
        System.out.println("Ciphertext: " + cipher);

        String decrypted = pf.decryptText(cipher);
        System.out.println("Decrypted Text: " + decrypted);

        sc.close();
    }
}

/*
1) Why Playfair Cipher is more secure than Caesar Cipher

The Caesar Cipher shifts single letters, making it easy 
to break using frequency analysis. The Playfair Cipher encrypts letter pairs,
hiding letter patterns and making it harder to break.

2) Purpose of inserting ‘X’ between identical letters

‘X’ is inserted to separate identical letters in a pair
so that encryption rules can be applied correctly and ambiguity is avoided.


3) Key Table for Keyword “MONARCHY”

After removing duplicates and combining I/J:

M O N A R
C H Y B D
E F G I K
L P Q S T
U V W X Z


4) Encrypt “BALLOON” (Step by Step)

Step 1 – Format plaintext

BALLOON → BA LX LO ON
(Insert X between LL)

Step 2 – Make pairs

BA | LX | LO | ON

Step 3 – Encryption using rules

BA → IB (rectangle rule)

LX → SU (rectangle rule)

LO → PM (rectangle rule)

ON → NA (same row → shift right)

Ciphertext:

IBSUPMNA