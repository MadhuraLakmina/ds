public class ColumnarTranspositionCipher {

    // Function to encrypt the plaintext using the Columnar Transposition Cipher
    public static String encrypt(String plaintext, String keyword) {
        // Remove spaces and convert the plaintext and keyword to uppercase
        plaintext = plaintext.replaceAll("\\s+", "").toUpperCase();
        keyword = keyword.toUpperCase();

        // Create the key order for columns based on the keyword
        int keyLength = keyword.length();
        int[] keyOrder = new int[keyLength];
        char[] sortedKeyword = keyword.toCharArray();
        Arrays.sort(sortedKeyword);

        for (int i = 0; i < keyLength; i++) {
            char ch = sortedKeyword[i];
            keyOrder[i] = keyword.indexOf(ch);
            keyword = keyword.replace(ch, ' ');
        }

        // Calculate the number of rows needed for the transposition grid
        int rows = (int) Math.ceil((double) plaintext.length() / keyLength);

        // Create the transposition grid
        char[][] transpositionGrid = new char[rows][keyLength];

        // Fill the grid with the plaintext characters
        int index = 0;
        for (int col = 0; col < keyLength; col++) {
            for (int row = 0; row < rows; row++) {
                if (index < plaintext.length()) {
                    transpositionGrid[row][keyOrder[col]] = plaintext.charAt(index);
                    index++;
                }
            }
        }

        // Read the encrypted characters column by column
        StringBuilder ciphertext = new StringBuilder();
        for (int col : keyOrder) {
            for (int row = 0; row < rows; row++) {
                if (transpositionGrid[row][col] != '\0') {
                    ciphertext.append(transpositionGrid[row][col]);
                }
            }
        }

        return ciphertext.toString();
    }

    // Function to decrypt the ciphertext using the Columnar Transposition Cipher
    public static String decrypt(String ciphertext, String keyword) {
        // Remove spaces and convert the ciphertext and keyword to uppercase
        ciphertext = ciphertext.replaceAll("\\s+", "").toUpperCase();
        keyword = keyword.toUpperCase();

        // Calculate the number of columns needed for the transposition grid
        int cols = (int) Math.ceil((double) ciphertext.length() / keyword.length());

        // Create the key order for columns based on the keyword
        int keyLength = keyword.length();
        int[] keyOrder = new int[keyLength];
        char[] sortedKeyword = keyword.toCharArray();
        Arrays.sort(sortedKeyword);

        for (int i = 0; i < keyLength; i++) {
            char ch = sortedKeyword[i];
            keyOrder[i] = keyword.indexOf(ch);
            keyword = keyword.replace(ch, ' ');
        }

        // Create the transposition grid
        char[][] transpositionGrid = new char[cols][keyLength];

        // Fill the grid with the ciphertext characters
        int index = 0;
        for (int col : keyOrder) {
            for (int row = 0; row < cols; row++) {
                if (index < ciphertext.length()) {
                    transpositionGrid[row][col] = ciphertext.charAt(index);
                    index++;
                }
            }
        }

        // Read the decrypted characters row by row
        StringBuilder plaintext = new StringBuilder();
        for (int row = 0; row < cols; row++) {
            for (int col = 0; col < keyLength; col++) {
                if (transpositionGrid[row][col] != '\0') {
                    plaintext.append(transpositionGrid[row][col]);
                }
            }
        }

        return plaintext.toString();
    }

    public static void main(String[] args) {
        String plaintext = "HELLO WORLD";
        String keyword = "KEY";

        String encryptedText = encrypt(plaintext, keyword);
        String decryptedText = decrypt(encryptedText, keyword);

        System.out.println("Plaintext: " + plaintext);
        System.out.println("Keyword: " + keyword);
        System.out.println("Encrypted: " + encryptedText);
        System.out.println("Decrypted: " + decryptedText);
    }
}