public class RSA {

    // Function to compute modular exponentiation (a^b mod m)
    private static long modPow(long a, long b, long m) {
        long result = 1;
        a %= m;

        while (b > 0) {
            if ((b & 1) == 1) {
                result = (result * a) % m;
            }
            b >>= 1;
            a = (a * a) % m;
        }

        return result;
    }

    // Function to encrypt the plaintext using the public key (e, n)
    public static long encrypt(long plaintext, long e, long n) {
        return modPow(plaintext, e, n);
    }

    // Function to decrypt the ciphertext using the private key (d, n)
    public static long decrypt(long ciphertext, long d, long n) {
        return modPow(ciphertext, d, n);
    }

    public static void main(String[] args) {
        // Key Generation (Replace these values with your own keys for a real implementation)
        long p = 61; // Prime number 1
        long q = 53; // Prime number 2
        long n = p * q;
        long phi = (p - 1) * (q - 1);
        long e = 17; // Public exponent (commonly chosen value)
        long d = 2753; // Private exponent (calculated using Extended Euclidean Algorithm)

        // Encryption and Decryption
        long plaintext = 1234;
        long ciphertext = encrypt(plaintext, e, n);
        long decryptedText = decrypt(ciphertext, d, n);

        System.out.println("Plaintext: " + plaintext);
        System.out.println("Ciphertext: " + ciphertext);
        System.out.println("Decrypted: " + decryptedText);
    }
}