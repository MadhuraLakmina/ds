public class OneTimePadCipher {

    // Function to encrypt the plaintext using the one-time pad key
    public static String encrypt(String plaintext, String key) {
        StringBuilder ciphertext = new StringBuilder();

        for (int i = 0; i < plaintext.length(); i++) {
            char ch = plaintext.charAt(i);

            // XOR each character with the corresponding key character
            char encryptedChar = (char) (ch ^ key.charAt(i));
            ciphertext.append(encryptedChar);
        }

        return ciphertext.toString();
    }

    // Function to decrypt the ciphertext using the one-time pad key
    public static String decrypt(String ciphertext, String key) {
        // Decryption is the same as encryption for the one-time pad
        return encrypt(ciphertext, key);
    }

    public static void main(String[] args) {
        String plaintext = "Hello, World!";
        String key = "RANDOMKEY123456789"; // Key must be as long as the plaintext

        if (plaintext.length() != key.length()) {
            System.out.println("Plaintext and key must have the same length.");
            return;
        }

        String encryptedText = encrypt(plaintext, key);
        String decryptedText = decrypt(encryptedText, key);

        System.out.println("Plaintext: " + plaintext);
        System.out.println("Key:       " + key);
        System.out.println("Encrypted: " + encryptedText);
        System.out.println("Decrypted: " + decryptedText);
    }
}